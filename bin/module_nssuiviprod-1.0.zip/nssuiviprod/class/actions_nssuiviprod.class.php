<?php
/* Copyright (C) 2026 Nicolas Silobre <contact@ns-info.fr>
 *
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program.  If not, see <https://www.gnu.org/licenses/>.
 */

/**
 * \file    nssuiviprod/class/actions_nssuiviprod.class.php
 * \ingroup nssuiviprod
 * \brief   Hooks of the module nssuiviprod
 */

/**
 * Class of the hooks of the module nssuiviprod
 */
class ActionsNssuiviprod
{
	/**
	 * @var DoliDB	Database handler
	 */
	public $db;

	/**
	 * @var string	Error message
	 */
	public $error = '';

	/**
	 * @var string[]	Error messages
	 */
	public $errors = array();

	/**
	 * @var array<string,mixed>	Results of the hook (read by the caller in $hookmanager->resArray)
	 */
	public $results = array();

	/**
	 * @var string	HTML code returned by the hook
	 */
	public $resprints = '';

	/**
	 * Constructor
	 *
	 * @param	DoliDB	$db		Database handler
	 */
	public function __construct($db)
	{
		$this->db = $db;
	}

	/**
	 * Permission to change the order of the lines by drag and drop (core/ajax/row.php): URLs of a site
	 *
	 * @param	array<string,mixed>	$parameters		Hook parameters (table_element_line, fk_element, element_id, perm)
	 * @param	CommonObject		$object			Object (GenericObject)
	 * @param	string				$action			Action
	 * @param	HookManager			$hookmanager	Hook manager
	 * @return	int									1 to use the permission of the module, 0 otherwise
	 */
	public function checkRowPerms($parameters, &$object, &$action, $hookmanager)
	{
		global $user;

		if ($parameters['table_element_line'] == 'nssuiviprod_siteurl' && $parameters['fk_element'] == 'fk_site' && isModEnabled('nssuiviprod')) {
			$this->results = array('perm' => ($user->hasRight('nssuiviprod', 'site', 'write') ? 1 : 0));
			return 1;
		}

		return 0;
	}
}
