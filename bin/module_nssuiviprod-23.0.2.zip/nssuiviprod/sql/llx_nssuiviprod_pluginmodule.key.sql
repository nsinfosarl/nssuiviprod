-- Copyright (C) 2026		Nicolas SILOBRE				<contact@ns-info.fr>
--
-- This program is free software: you can redistribute it and/or modify
-- it under the terms of the GNU General Public License as published by
-- the Free Software Foundation, either version 3 of the License, or
-- (at your option) any later version.
--
-- This program is distributed in the hope that it will be useful,
-- but WITHOUT ANY WARRANTY; without even the implied warranty of
-- MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
-- GNU General Public License for more details.
--
-- You should have received a copy of the GNU General Public License
-- along with this program.  If not, see https://www.gnu.org/licenses/.


-- BEGIN MODULEBUILDER INDEXES
ALTER TABLE llx_nssuiviprod_pluginmodule ADD INDEX idx_nssuiviprod_pluginmodule_rowid (rowid);
ALTER TABLE llx_nssuiviprod_pluginmodule ADD INDEX idx_nssuiviprod_pluginmodule_entity (entity);
ALTER TABLE llx_nssuiviprod_pluginmodule ADD INDEX idx_nssuiviprod_pluginmodule_ref (ref);
-- END MODULEBUILDER INDEXES

-- One line by module (technical name) and entity
ALTER TABLE llx_nssuiviprod_pluginmodule ADD UNIQUE INDEX uk_nssuiviprod_pluginmodule_ref (ref, entity);
